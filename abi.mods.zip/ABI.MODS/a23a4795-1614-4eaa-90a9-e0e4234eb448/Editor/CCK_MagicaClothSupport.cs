﻿using System;
using System.Linq;
using ABI.CCK.Scripts.Editor;
using MagicaCloth;
using UnityEditor;
using UnityEngine;
using Random = System.Random;

namespace ABI.MODS.MagicaClothSupport.Editor
{
    [InitializeOnLoad]
    public class CCK_MagicaClothSupport
    {
        static CCK_MagicaClothSupport()
        {
            CCK_BuildUtility.PreAvatarBundleEvent.AddListener(PreBundleEvent);
            CCK_BuildUtility.PrePropBundleEvent.AddListener(PreBundleEvent);
            Debug.Log("[Module] CCK_MagicaClothSupport attached to PreAvatarBundleEvent");
            
            string cckSymbol = "CCK_ADDIN_MAGICACLOTHSUPPORT";
            string defines = PlayerSettings.GetScriptingDefineSymbolsForGroup(EditorUserBuildSettings.selectedBuildTargetGroup);
            if (!defines.Contains(cckSymbol))
            {
                PlayerSettings.SetScriptingDefineSymbolsForGroup(EditorUserBuildSettings.selectedBuildTargetGroup, (defines + ";" + cckSymbol));
                Debug.Log("[CCK] [Module => CCK_MagicaClothSupport] Added CCK_ADDIN_MAGICACLOTHSUPPORT Scripting Symbol.");
            }
        }

        public static void PreBundleEvent(GameObject uploadedObject)
        {
            if (!AssetDatabase.IsValidFolder("Assets/ABI.CCK/Resources/MagicaConfigs"))
                    AssetDatabase.CreateFolder("Assets/ABI.CCK/Resources", "MagicaConfigs");

            AssetDatabase.SaveAssets();
            
            var boneCloths = uploadedObject.GetComponentsInChildren<MagicaBoneCloth>();
            foreach (var boneCloth in boneCloths)
            {
                if (boneCloth.ClothData != null && String.IsNullOrEmpty(AssetDatabase.GetAssetPath(boneCloth.ClothData)))
                {
                    AssetDatabase.CreateAsset(boneCloth.ClothData,
                        "Assets/ABI.CCK/Resources/MagicaConfigs/" + boneCloth.name + "_cloth-data_" + 
                        RandomString(8) + ".asset");
                }

                if (boneCloth.ClothSelection != null && String.IsNullOrEmpty(AssetDatabase.GetAssetPath(boneCloth.ClothSelection)))
                {
                    AssetDatabase.CreateAsset(boneCloth.ClothSelection,
                        "Assets/ABI.CCK/Resources/MagicaConfigs/" + boneCloth.name + "_cloth-selection_" + 
                        RandomString(8) + ".asset");
                }
                
                if (boneCloth.MeshData != null && String.IsNullOrEmpty(AssetDatabase.GetAssetPath(boneCloth.MeshData)))
                {
                    AssetDatabase.CreateAsset(boneCloth.MeshData,
                        "Assets/ABI.CCK/Resources/MagicaConfigs/" + boneCloth.name + "_mesh-data_" + 
                        RandomString(8) + ".asset");
                }
            }
            
            var boneSprings = uploadedObject.GetComponentsInChildren<MagicaBoneSpring>();
            foreach (var boneSpring in boneSprings)
            {
                if (boneSpring.ClothData != null && String.IsNullOrEmpty(AssetDatabase.GetAssetPath(boneSpring.ClothData)))
                {
                    AssetDatabase.CreateAsset(boneSpring.ClothData,
                        "Assets/ABI.CCK/Resources/MagicaConfigs/" + boneSpring.name + "_cloth-data_" + 
                        RandomString(8) + ".asset");
                }

                if (boneSpring.ClothSelection != null && String.IsNullOrEmpty(AssetDatabase.GetAssetPath(boneSpring.ClothSelection)))
                {
                    AssetDatabase.CreateAsset(boneSpring.ClothSelection,
                        "Assets/ABI.CCK/Resources/MagicaConfigs/" + boneSpring.name + "_cloth-selection_" + 
                        RandomString(8) + ".asset");
                }
                
                if (boneSpring.MeshData != null && String.IsNullOrEmpty(AssetDatabase.GetAssetPath(boneSpring.MeshData)))
                {
                    AssetDatabase.CreateAsset(boneSpring.MeshData,
                        "Assets/ABI.CCK/Resources/MagicaConfigs/" + boneSpring.name + "_mesh-data_" + 
                        RandomString(8) + ".asset");
                }
            }
            
            var meshCloths = uploadedObject.GetComponentsInChildren<MagicaMeshCloth>();
            foreach (var meshCloth in meshCloths)
            {
                if (meshCloth.ClothData != null && String.IsNullOrEmpty(AssetDatabase.GetAssetPath(meshCloth.ClothData)))
                {
                    AssetDatabase.CreateAsset(meshCloth.ClothData,
                        "Assets/ABI.CCK/Resources/MagicaConfigs/" + meshCloth.name + "_cloth-data_" + 
                        RandomString(8) + ".asset");
                }

                if (meshCloth.ClothSelection != null && String.IsNullOrEmpty(AssetDatabase.GetAssetPath(meshCloth.ClothSelection)))
                {
                    AssetDatabase.CreateAsset(meshCloth.ClothSelection,
                        "Assets/ABI.CCK/Resources/MagicaConfigs/" + meshCloth.name + "_cloth-selection_" + 
                        RandomString(8) + ".asset");
                }
            }
            
            var meshSprings = uploadedObject.GetComponentsInChildren<MagicaMeshSpring>();
            foreach (var meshSpring in meshSprings)
            {
                if (meshSpring.ClothData != null && String.IsNullOrEmpty(AssetDatabase.GetAssetPath(meshSpring.ClothData)))
                {
                    AssetDatabase.CreateAsset(meshSpring.ClothData,
                        "Assets/ABI.CCK/Resources/MagicaConfigs/" + meshSpring.name + "_cloth-data_" + 
                        RandomString(8) + ".asset");
                }

                if (meshSpring.ClothSelection != null && String.IsNullOrEmpty(AssetDatabase.GetAssetPath(meshSpring.ClothSelection)))
                {
                    AssetDatabase.CreateAsset(meshSpring.ClothSelection,
                        "Assets/ABI.CCK/Resources/MagicaConfigs/" + meshSpring.name + "_cloth-selection_" + 
                        RandomString(8) + ".asset");
                }
                
                if (meshSpring.SpringData != null && String.IsNullOrEmpty(AssetDatabase.GetAssetPath(meshSpring.SpringData)))
                {
                    AssetDatabase.CreateAsset(meshSpring.SpringData,
                        "Assets/ABI.CCK/Resources/MagicaConfigs/" + meshSpring.name + "_spring-data_" + 
                        RandomString(8) + ".asset");
                }
            }
            
            var renderDeformers = uploadedObject.GetComponentsInChildren<MagicaRenderDeformer>();
            foreach (var renderDeformer in renderDeformers)
            {
                if (renderDeformer.Deformer != null && renderDeformer.Deformer.MeshData != null && String.IsNullOrEmpty(AssetDatabase.GetAssetPath(renderDeformer.Deformer.MeshData)))
                {
                    AssetDatabase.CreateAsset(renderDeformer.Deformer.MeshData,
                        "Assets/ABI.CCK/Resources/MagicaConfigs/" + renderDeformer.name + "_mesh-data_" + 
                        RandomString(8) + ".asset");
                }
            }
            
            var virtualDeformers = uploadedObject.GetComponentsInChildren<MagicaVirtualDeformer>();
            foreach (var virtualDeformer in virtualDeformers)
            {
                if (virtualDeformer.Deformer != null && virtualDeformer.Deformer.MeshData != null && String.IsNullOrEmpty(AssetDatabase.GetAssetPath(virtualDeformer.Deformer.MeshData)))
                {
                    AssetDatabase.CreateAsset(virtualDeformer.Deformer.MeshData,
                        "Assets/ABI.CCK/Resources/MagicaConfigs/" + virtualDeformer.name + "_mesh-data_" + 
                        RandomString(8) + ".asset");
                }
            }
            
            AssetDatabase.SaveAssets();
        }
        
        public static string RandomString(int length)
        {
            Random random = new Random();
            const string chars = "ABCDEF0123456789";
            return new string(Enumerable.Repeat(chars, length)
                .Select(s => s[random.Next(s.Length)]).ToArray());
        }
    }
}